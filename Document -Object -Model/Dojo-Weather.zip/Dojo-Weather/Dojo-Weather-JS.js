var agreement = document.querySelector("#cookie-box") //targets box as a whole element

function makeDisappear() {
    agreement.style.display= "none";
}
//sets css style display to none  when accept clicked
//Makes the cookie acceptance box disappear


//COOKIE CLICK//COOKIE CLICK//COOKIE CLICK//COOKIE CLICK//COOKIE CLICK
//COOKIE CLICK//COOKIE CLICK//COOKIE CLICK//COOKIE CLICK//COOKIE CLICK


//DEGREE TYPE////DEGREE TYPE////DEGREE TYPE////DEGREE TYPE//
//DEGREE TYPE////DEGREE TYPE////DEGREE TYPE////DEGREE TYPE//

//sets alert when type changed
function changeDegreeType(weather) {
    alert("You have selected: " + weather.value);
}



//CHANGE DEGREE IN CARDS////CHANGE DEGREE IN CARDS////CHANGE DEGREE IN CARDS//
//CHANGE DEGREE IN CARDS////CHANGE DEGREE IN CARDS////CHANGE DEGREE IN CARDS//
    //NOTES:
//function to convert celcius to farenheight
//using select form options ONCHANGE
//temps in cards are highs and lows so convert the same when INNERTEXT

// var changeType = document.querySelectorAll("#tempNumber")
// function changeDegreeType(element) {
//     console.log(element.value)
//     if(element.value = "°C"){
//         console.log('c')
//         var conv = changeType.replace( /^\D+/g, '')
//         console.log(conv)
//     }
// }
// var tempy = 0
// function changeDegreeType(element) {
//     console.log('hi')
//     tempy =  changeType.parseInt(element);
//     console.log(tempy) }

// take the current value of each temp reading
//divide by 5, multiply by 9, add 32 ; C -> F
//subtract 32, multiply by 5, divide by 9; F -> C
//starts going TO celcius

//we have to determine whether C or F is selected
//then use appropriate formula to convert then change innertext



//USE THIS CODE HERE//USE THIS CODE HERE//USE THIS CODE HERE//USE THIS CODE HERE
//USE THIS CODE HERE//USE THIS CODE HERE//USE THIS CODE HERE//USE THIS CODE HERE

// var arr = [document.querySelector("#tempNumber0"),document.querySelector("#tempNumber1"),
//             document.querySelector("#tempNumber2"),document.querySelector("#tempNumber3"),
//             document.querySelector("#tempNumber4"),document.querySelector("#tempNumber5"),
//             document.querySelector("#tempNumber6"),document.querySelector("#tempNumber7")]
// var ele = 0
// function changeDegreeType(element){
//     console.log('hi')
//     console.log(element.value)
//     if(element.value === "°C") {
//         for(var i = 0; i < arr.length; i++) {
//             // console.log(arr[i]) 
//             arr[i].innerText = "0°" } 
//     }
//     else if(element.value === "°F") {
//         for(var i = 0; i < arr.length; i++) {
//             // console.log(arr[i]) 
//             arr[i].innerText = "32°" }
//         }
//     }
//USE THIS CODE HERE//USE THIS CODE HERE//USE THIS CODE HERE//USE THIS CODE HERE//USE THIS CODE HERE
//USE THIS CODE HERE//USE THIS CODE HERE//USE THIS CODE HERE//USE THIS CODE HERE//USE THIS CODE HERE




    //HOW GET INTEGER FROM STRING AND DO MATH ON IT???????????????
var arr = [document.querySelector("#tempNumber0"),document.querySelector("#tempNumber1"),
document.querySelector("#tempNumber2"),document.querySelector("#tempNumber3"),
document.querySelector("#tempNumber4"),document.querySelector("#tempNumber5"),
document.querySelector("#tempNumber6"),document.querySelector("#tempNumber7")]
var ele = 0
function changeDegreeType(element){
    console.log('hi')
    var EV = (element.value);
    console.log(EV)  //EV is current C or F
        if(EV == "°F") {
            for(var i = 0; i < arr.length; i ++) {
                console.log(arr[i].innerText) //now we are accessing the values of  arr 
                var pI = parseInt(arr[i].innerText) //extracts num from array temp values
                // console.log(pI)
                var changeToC = (pI-32)*5/9 //doin the math // subtract 32, multiply by 5, divide by 9; F -> C
                console.log(changeToC)
                arr[i].innerText = Math.round(changeToC) //rounding UP
                }
            }
            else if(EV == "°C") {
                for(var i = 0; i < arr.length; i ++) {
                    console.log(arr[i].innerText) //now we are accessing the values of  arr 
                    var pI = parseInt(arr[i].innerText)
                    // console.log(pI)
                    var changeToF = (pI/5)*9 + 32; //doin the math    // divide by 5, multiply by 9, add 32 ; C -> F
                    //console.log(changeToF)
                    arr[i].innerText = Math.round(changeToF) //rounding UP
                    }
                }
    }




   //BOTH WAYS WORk!!!! ONE DOES MATH!!! 