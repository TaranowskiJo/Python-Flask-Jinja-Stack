//cart alert
var cart = document.querySelector("#cart")
function cartCount() {
    if(cart.innerText == ""){
        console.log('hi')
        alert ("Your cart is empty!")
    }
} 

//MIGHT ADD EXTRA CARD CARD? 
//nevermind
var cookies = document.querySelector("#pop-up")
function disappear() {
    cookies.style.display = "none";
}


//hover image change main container
var photoMain = document.querySelector("#succulents")
function change() {
    console.log('hi')
    photoMain.src = "succulents-2.jpg"
}

function changeBack() {
    console.log('Bye')
    photoMain.src = "succulents-1.jpg"
}




///this is just me trying to add stuff for myself
// var add = document.querySelector(".lower-bar").innerHTML;
// var cartList = document.querySelector("#cart-total")
// var stock = ["aeonium","aloe","cactus","echeveria","sedum","sempervivum","succulent"]
// var shoppingCart = [];
// var count = 0
// var hiddenCart = document.querySelector("#ninjaCart")
// function addToCart(element){
//     console.log('hi')
//     shoppingCart.push(stock[element])
//     console.log(shoppingCart)
//     count += 1
//     cartList.innerText = count
//     tempMenu.innerText = shoppingCart
//     shoppingItem+count.innerhtml
// }
// var myShopping = document.querySelector("#yourShopping")
// function display() {

//  myShopping.style.visibility = "visible"
// }

// function hide() {
//     myShopping.style.visibility = "hidden"
// }
// var cartItem = document.querySelector("")