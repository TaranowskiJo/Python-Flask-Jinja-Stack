from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

import re
email_regex = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
#NECESSARY FOR EMAIL VALIDATION IN VALIDATE USER

class User():
    def __init__( self , data ):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.ninjas = [] #the dojos list of employees

    @classmethod
    def register_user(cls,data):
        query = "INSERT INTO user_data (first_name,last_name,email,password) VALUES (%(first_name)s,%(last_name)s,%(email)s,%(password)s);"
        result = connectToMySQL('login_reg').query_db(query,data)

        return result #don't really need here but will for most queries, KEEP PATTERNS




    @classmethod #REUSABLE FOR VERIFYING OTHER ELEMENTS BUT I FIGURED EASIEST FOR EMAIL
    def get_user_by_email(cls,data):
        query = "SELECT * FROM user_data WHERE email = %(email)s"
        results = connectToMySQL('login_reg').query_db(query,data)
        users = []
        for row in results:
            users.append(User(row))
        return users


    @staticmethod
    def validate_user(data):
        is_valid = True

        #first name
        if len(data['first_name']) <3 or len(data['first_name']) > 20:
            is_valid = False
            flash("First name must be between 2 and 20 characters in length!")
        #last name
        if len(data['last_name']) <3 or len(data['last_name']) > 20:
            is_valid = False
            flash("Last name must be between 2 and 20 characters in length!")
        #email --- would be basically the same to check username is different
        if not email_regex.match(data['email']):
            is_valid = False
            flash("Email must be in correct format ")
        if len(User.get_user_by_email(data)) != 0:
            is_valid = False
            flash("Email already Taken, Try Logging In!")

        
        #password
        if len(data['password']) < 8:
            is_valid = False
            flash("Password much be at least 9 characters in length")
        #confirm password
        if data['password'] != data['confirm_password']:
            is_valid = False
            flash("Passwords do not match")

        return is_valid


