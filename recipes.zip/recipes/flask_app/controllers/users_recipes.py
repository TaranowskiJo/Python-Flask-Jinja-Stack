from flask import render_template, request, redirect, session, flash
from flask_app import app
from flask_bcrypt import Bcrypt
from flask_app.models.user import User, Recipe #imports from reg model the Reg class

bcrypt = Bcrypt(app) #creates a bcrypt object to use in application


@app.route('/')
def index():

    return render_template("index.html")
    #all_ninjas not displaying anywhere on index.html in this case and is unnecessary


#Register User
@app.route('/user/register', methods = ["POST"])
def handle_registration_form(): 
    #TEST VALIDATIONS BEFORE BUILDING OUT
    if User.validate_user(request.form):
        print("Registration OK!")
        data ={
            'first_name': request.form['first_name'],
            'last_name': request.form['last_name'],
            'email': request.form['email'],
            'password': bcrypt.generate_password_hash(request.form['password']), #PASSWORD NEEDS TO BE HASHED HERE
        }
        print(data) #just checking data in the console
        User.register_user(data)
    else:
        print ("FAILED VALIDATION!")
    return redirect ('/')

#LOG IN USER#
@app.route('/user/log_in', methods = ["POST"])
def handle_log_in_form():

    users = User.get_user_by_email({'email':request.form['email']}) #because we are only passing one   item through but you could still use data if you wanted

    if len(users) != 1: #if not equal to 1, user doesn't exist yet! go register instead lol
        flash("Email or password INCORRECT")
        return redirect('/')

    user = users[0] #user is used in line 50, users list from get_user_by_email method

    if not bcrypt.check_password_hash(user.password, request.form['password']):
        #SPECIFIC ORDER (from database, from form)
        flash("Email or password is incorrect")
        return redirect('/')

    session['user_id'] = user.id #USER ID 
    session['user_email'] = user.email #USER ID 
    session['user_first_name'] = user.first_name #USER ID 
    #could have a session with username but not on this assignment lol
    #remove session(user.id) from top of html after testing

    print("login ok")
    return redirect ('/recipes') #oon accessible if user logged in successfully

@app.route('/recipes')
def success():
    if 'user_id' not in session: #insures actually logged in not manually typed in
        flash("Log in to view this page!")
        return redirect('/')
    recipes = Recipe.get_all_recipes()
    return render_template('recipes.html', all_recipes = recipes) #redirects them to html pages only for logged in users

@app.route('/logout')
def logout():
    session.clear()
    flash("Logout Successful")
    return redirect('/')

@app.route('/user/new/recipe')
def create_recipe():
    return render_template('add_new.html')

#Submit new Recipe
@app.route('/register_recipe', methods = ["POST"])
def handle_recipe_registration(): 
    #TEST VALIDATIONS BEFORE BUILDING OUT
    if Recipe.validate_recipe(request.form):
        print("Adding Recipe...")
        data ={
            'name': request.form['name'],
            'user_id': session['user_id'],
            'description': request.form['description'],
            'instructions': request.form['instructions'],
            'date_made': request.form['date_made'],
            'under_thirty': request.form['under_thirty']
        }
        print(data) #just checking data in the console
        Recipe.register_recipe(data)
        return redirect('/recipes')
    else:
        print ("FAILED VALIDATION!")
    return redirect ('/user/new/recipe')


#View Recipe Page
@app.route('/recipe_info/<int:id>')
def view_recipe(id):
    data = {
        'id':id
    }
    recipe = Recipe.get_a_recipe(data)
    return render_template('recipe_info.html', recipe = recipe)

#TO DELETE 
@app.route('/<int:id>/delete')
def delete_recipe(id):
    data  = {
        'id': id
    }
    
    Recipe.delete_recipe(data)
    return redirect('/recipes')



#EDITING
#need 1 for template, 1 for actual updating
@app.route('/edit/<int:id>')
def edit_recipe(id):
    data  = {
        'id': id
    }

    recipe = Recipe.get_a_recipe(data)

    print(session['user_id'])
    if recipe['user_id'] != session['user_id']: #recipe as dic because returned result[0]
        return redirect('/recipes')

    return render_template('recipe_edit.html', recipe = recipe)

@app.route('/update/<int:id>',methods = ["POST"])
def update_recipe(id):
    data  = {
    'id': id,
    'name':request.form['name'],
    'instructions': request.form['instructions'],
    'description': request.form['description'],
    'under_thirty': request.form['under_thirty'],
    'date_made': request.form['date_made']
    }
    Recipe.update_recipe(data)
    
    return redirect(f'/recipes')