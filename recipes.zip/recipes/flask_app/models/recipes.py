from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Recipe():
    def __init__( self , data ):
        self.id = data['id']
        self.user_id = data['user_id']
        self.under_thirty = data['under_thirty']
        self.instructions = data['instructions']
        self.description = data['description']
        self.date_made = data['date_made']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']


#validate recipe
    @staticmethod
    def validate_recipe(data):
        is_valid = True
        #name
        if len(data['name']) <3 or len(data['name']) > 40:
            is_valid = False
            flash("Recipe Name must be between 2 and 40 characters in length!")
        #instructions
        if len(data['instructions']) < 5 or len(data['instructions']) > 255:
            is_valid = False
            flash("Instructions must be between 5 and 255 characters ")
        #description
        if len(data['description']) <5 or len(data['description']) > 60:
            is_valid = False
            flash("Description must be between 5 and 60 characters in length!")
        #date made
            #maybe if i get here...
        return is_valid

#recipe registration
    @classmethod
    def register_recipe(cls,data):
        query = "INSERT INTO recipes (name,user_id,instructions,description,date_made,under_thirty) VALUES (%(name)s,%(user_id)s,%(instructions)s,%(description)s,%(date_made)s,%(under_thirty)s);"
        result = connectToMySQL('recipes_share').query_db(query,data)

        return result #don't really need here but will for most queries, KEEP PATTERNS

#get a single recipe
    @classmethod
    def get_a_recipe(cls,data):
        query = "SELECT * FROM recipes LEFT JOIN users ON recipes.user_id = users.id WHERE recipes.id = %(id)s;"
        result = connectToMySQL('recipes_share').query_db(query,data)

        return result[0] # grab info for that recipe!!

#get all get all recipes and user name by left join user id 
    @classmethod
    def get_all_recipes(cls):
        query = "SELECT * FROM recipes LEFT JOIN users ON recipes.user_id = users.id;;"
        results = connectToMySQL('recipes_share').query_db(query)

        return results

    @classmethod
    def delete_recipe(cls,data):
        query = "DELETE FROM recipes WHERE id = %(id)s"
        results = connectToMySQL('recipes_share').query_db(query,data)

        return results #don't rlly need return on deletes

    @classmethod
    def update_recipe(cls,data):
        query = "UPDATE recipes SET name = %(name)s, instructions = %(instructions)s, description = %(description)s, date_made = %(date_made)s, under_thirty = %(under_thirty)s WHERE id = %(id)s;"
        results = connectToMySQL('recipes_share').query_db(query,data)

        return results